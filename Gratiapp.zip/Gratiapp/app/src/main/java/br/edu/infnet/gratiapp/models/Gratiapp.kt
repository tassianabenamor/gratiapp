package br.edu.infnet.gratiapp.models

data class Gratiapp(
    val nomeGratiapp: String = "",
    val data: String = "",
    val humor: String = "",
    val agradecer: String = ""
)
