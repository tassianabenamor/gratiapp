package br.edu.infnet.gratiapp.models

data class GratiappWithId(
    val nomeGratiapp: String = "",
    val data: String = "",
    val humor: String = "",
    val agradecer: String = "",
    var id: String = ""
)
